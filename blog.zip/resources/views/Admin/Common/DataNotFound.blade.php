<div class="card mb-5 mb-xl-8">
    <div class="card-body">
        <div class="d-flex flex-center flex-column py-5">
            <div class="mb-1">
                <div class="mt-1">
                    <h1 class="fw-bolder text-gray-900 mb-5">Data Not Found !</h1>
                </div>
            </div>
        </div>
    </div>
</div>
