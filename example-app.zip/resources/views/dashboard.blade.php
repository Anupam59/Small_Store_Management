@extends('Admin.Layout.main')

@section('content')

<h1>Dashboard </h1>

@endsection
